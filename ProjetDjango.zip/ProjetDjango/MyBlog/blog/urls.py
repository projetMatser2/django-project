from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from . import views

app_name = 'blog'
#path('', views.post_list.as_view(), name='post_list'),
urlpatterns = [
	path('', views.post_list, name='post_list'),
	path('post/new/', views.post_new, name='post_new'),
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
    path('post/<int:pk>/edit/', views.post_edit, name='post_edit'),
    path('post/<int:pk>/delete/', views.post_delete, name='post_delete'),
    path('post/<int:pk>/comment/', views.add_comment_to_post, name='add_comment_to_post'),
    path('connexion/', views.connexion, name='connexion'),
    path('deconnexion/', views.deconnexion, name='deconnexion'),
    path('bloggerposts/<int:user>/', views.bloggerposts, name='bloggerposts'),
    path('blogger_post_detail/<int:pk>/', views.blogger_post_detail, name='blogger_post_detail'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
