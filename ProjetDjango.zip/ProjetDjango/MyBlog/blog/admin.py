from django.contrib import admin
from .models import Post,Comment

# Register your models here.

class CommentInline(admin.TabularInline):
     model = Comment
     extra = 0


class PostAdmin(admin.ModelAdmin):
     fieldsets = [
         (None,               {'fields': ['title', 'author', 'text','picture'] }),
         ('Date information', {'fields': ['published_date'], 'classes': ['collapse']}),

     ]
     inlines = [CommentInline]
     list_display = ('title', 'author', 'published_date', 'text','picture', 'was_published_recently')
     list_filter = ['published_date']
     search_fields = ['title']
admin.site.register(Post,PostAdmin)

# Register your models here.
