from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render , get_object_or_404, render,redirect
from .forms import PostForm ,CommentForm ,ConnexionForm
from django.urls import reverse
from django.views import generic
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import Group , User
from django.contrib.auth.decorators import login_required,permission_required
from .models import Comment, Post
from django.conf import settings
from django.utils import timezone
 
# class IndexView(generic.ListView):
#     template_name = 'blog/index.html'
#     context_object_name = 'latest_publicite_list'

#     def get_queryset(self):
    
#     # Return the last five published questions (not including those set to be
#     # published in the future).
    
# 	    return Publicite.objects.filter(
# 	        pub_date__lte=timezone.now()
# 	    ).order_by('-pub_date')[:5]


# # class DetailView(generic.DetailView):
# #     model = Publicite
# #     template_name = 'blog/lire_article.html'
# #     def get_queryset(self):
# #         """
# #         Excludes any questions that aren't published yet.
# #         """
# #         return Publicite.objects.filter(pub_date__lte=timezone.now())
# def DetailView(request, pub_id):
#     """
#     Affiche un article complet, sélectionné en fonction du slug
#     fourni en paramètre
#     """
#     article = get_object_or_404(Publicite, id=pub_id)

#     #return render(request, 'blog/lire_article.html', {'article': article})
#     #return HttpResponseRedirect(reverse('blog:blog_lire', args=(article.id,)))
#     return render(request, 'blog/lire_article.html', {'article': article})
# ##class ContactUpdate(generic.ContactUpdate): 
# ##    model = Contact
# ##class ContactDelete(generic.ContactDelete): 
# ##    model = Contact

# ##class ResultsView(generic.DetailView):

# ##    model = Question
# ##    template_name = 'polls/results.html'

# def comment(request, pub_id):
#     article = get_object_or_404(Publicite, pk=pub_id)
#     current_pub = article.commentaire_set.create(commentaire_text=request.POST['message'])
#         #current_pub = article.commentaire_set.get(pk=request.POST['message'])
#         #current_pub = article.commentaire_set.create(commentaire_text=request.POST['message'])
         
#         # Always return an HttpResponseRedirect after successfully dealing
#         # with POST data. This prevents data from being posted twice if a
#         # user hits the Back button.
#     return render(request, 'blog/lire_article.html', {'article': article}, )

# Create your views here.
def post_list(request):
     posts_list = Post.objects.filter(published_date__lte=timezone.now()).order_by('published_date').reverse()
    
     query = request.GET.get("query")
     if query:
         posts_list = posts_list.filter(title__icontains=query)
     page = request.GET.get('page', 1)
     paginator = Paginator(posts_list, 3)
     try:
         posts = paginator.page(page)
     except PageNotAnInteger:
         posts = paginator.page(1)
     except EmptyPage:
         posts = paginator.page(paginator.num_pages)

     return render(request, 'blog/post_list.html', {'posts': posts})

# Create your views here.
""" class post_list(generic.ListView):
     model = Post
     template_name = 'blog/post_list.html'
     context_object_name = 'posts'
     posts_list = Post.objects.filter(published_date__lte=timezone.now()).order_by('published_date').reverse()
     
     def get_queryset(request):
        query = request.GET.get("query")
        if query:
            posts_list = posts_list.filter(title__icontains=query)
        page = request.GET.get('page', 1)
        paginator = Paginator(posts_list, 3)
        try:
            posts = paginator.page(page)
        except PageNotAnInteger:
            posts = paginator.page(1)
        except EmptyPage:
            posts = paginator.page(paginator.num_pages)
        return posts
 """

def post_detail(request, pk):
    form = CommentForm()
    post = get_object_or_404(Post, pk=pk)
    context ={ 'post': post ,'form': form}
    return render(request, 'blog/post_detail.html', context)

@login_required 
def post_new(request):
    grp = Group.objects.get(name='bloggers').user_set.all()
    if request.user in grp : 
        if request.method == "POST":
            form = PostForm(request.POST or None)
            if form.is_valid():
                post = form.save(commit=False)
                post.author = request.user
                post.published_date = timezone.now()
                post.save()
                return redirect('blog:blogger_post_detail', pk=post.pk)
        else:
            form = PostForm()
        return render(request, 'blog/post_add.html', {'form': form})
    else:
        return redirect('/blog/connexion/')

@login_required
def post_edit(request, pk):
    grp = Group.objects.get(name='bloggers').user_set.all()
    if request.user in grp :
        post = get_object_or_404(Post, pk=pk)
        if request.method == "POST":
            form = PostForm(request.POST, instance=post)
            if form.is_valid():
                post = form.save(commit=False)
                post.author = request.user
                post.published_date = timezone.now()
                post.save()
                return redirect('blog:blogger_post_detail', pk=post.pk)
        else:
            form = PostForm(instance=post)
            return render(request, 'blog/post_edit.html', {'form': form})
    else:
        return redirect('/blog/connexion/')

@login_required
def post_delete(request, pk):
    grp = Group.objects.get(name='bloggers').user_set.all()
    if request.user in grp :
        post = get_object_or_404(Post, pk=pk)
        post.delete()
        return redirect('blog:bloggerposts', request.user.id)
    else:
        return redirect('/blog/connexion/')

@login_required
def blogger_post_detail(request, pk):
    grp = Group.objects.get(name='bloggers').user_set.all()
    if request.user in grp :
        form = CommentForm()
        post = get_object_or_404(Post, pk=pk)
        context ={ 'post': post ,'form': form}
        return render(request, 'blog/blogger_post_detail.html', context)
    else:
        return redirect('/blog/connexion/')
     
def add_comment_to_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == "POST":
        form = CommentForm(request.POST)
        formVide = CommentForm()
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.save()
            context ={ 'post': post ,'form': formVide}
            parent_obj = None
            try:
                parent_id=int(request.POST.get("parent_id"))
            except:
                parent_id = None
            if parent_id :
                #parent_qs = Comment.objects.filter(id=parent_id)
                parent_qs = get_object_or_404(Comment,pk=parent_id)
                if parent_qs :
                    parent_obj = form.save(commit=False)
                    comment.post = post
                    parent_obj.parent = parent_qs
                    parent_obj.save()
            if request.user.is_authenticated:
                return render(request, 'blog/blogger_post_detail.html', context)
            else:
                return render(request, 'blog/post_detail.html', context)
    else:
        form = CommentForm()
    return render(request, 'blog/post_detail.html', {'form': form})

def connexion(request):
    error = False
    if request.method == "POST":
        form = ConnexionForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = authenticate(username=username, password=password)  # Nous vérifions si les données sont correctes
            if user:  # Si l'objet renvoyé n'est pas None
                login(request, user)  # nous connectons l'utilisateur
                grp = Group.objects.get(name='bloggers').user_set.all()
                if request.user in grp :
                    #user_posts=Post.objects.filter(author=request.user).order_by('-published_date').reverse()
                    #return render(request, 'bloggerprofil', {'user_posts':user_posts})
                    #return HttpResponseRedirect(reverse('blog:bloggerprofil', args=(request.user.id)))
                    return redirect('blog:bloggerposts',request.user.id)
                else :
                    return HttpResponse("Salut, {0} !".format(request.user.username))   
            else: # sinon une erreur sera affichée
                error = True
    else:
        form = ConnexionForm()
    return render(request, '../templates/registration/login.html', locals())

def deconnexion(request):
    logout(request)
    return redirect('/blog/connexion/')
    
@login_required
#@permission_required('request.user.is_authenticated()')
def bloggerposts(request, user):
    grp = Group.objects.get(name='bloggers').user_set.all()
    if request.user in grp :
        posts_list=Post.objects.filter(author=user).order_by('-published_date')
        template = 'blog/blogger_post_list.html'
        us=User.objects.get(id=user)

        query = request.GET.get("query")
        if query:
            posts_list = posts_list.filter(title__icontains=query)
        page = request.GET.get('page', 1)
        paginator = Paginator(posts_list, 3)
        try:
            user_posts = paginator.page(page)
        except PageNotAnInteger:
            user_posts = paginator.page(1)
        except EmptyPage:
            user_posts = paginator.page(paginator.num_pages)
        return render(request,template,{'user_posts':user_posts,'us':us})
    else:
        return redirect('/blog/connexion/')